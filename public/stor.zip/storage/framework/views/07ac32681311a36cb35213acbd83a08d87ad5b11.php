<?php $__env->startSection('page_title', $dataType->getTranslatedAttribute('display_name_plural') . ' ' . __('voyager::bread.order')); ?>

<?php $__env->startSection('page_header'); ?>
<h1 class="page-title">
    <i class="voyager-list"></i>Ordonare si creare subtipuri
</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-bordered">
                <div class="panel-heading">
                    <p class="panel-title" style="color:#777">Rearanjeaza elementele si muta-le pentru a seta subtipurile(Ex. Un element devine subtip daca se afla in interiorul unui tip)</p>
                </div>
                <div class="panel-body" style="padding:30px;">
                    <div class="dd">
                        <ol class="dd-list">
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($result->parent_id == null): ?>
                                  <li class="dd-item" data-id="<?php echo e($result->id); ?>">
                                      <div class="dd-handle" style="height:inherit">
                                         <span><?php echo e($result->{$display_column}); ?></span>
                                      </div>
                                      <?php if($result->children != null && !$result->children->isEmpty()): ?>
                                          <?php echo $__env->make('voyager::offer-types.suborder', ['items' => $result->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                      <?php endif; ?>
                                  </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<script>
$(document).ready(function () {
//     $('.dd').nestable({
//         maxDepth: 999
//     });
  
      $('.dd').nestable({
        expandBtnHTML: '',
        collapseBtnHTML: '',
        maxDepth: 2
    });

    /**
    * Reorder items
    */
    $('.dd').on('change', function (e) {
        $.post("/admin/orderOffer", {
            order: JSON.stringify($('.dd').nestable('serialize')),
            _token: '<?php echo e(csrf_token()); ?>'
        }, function (data) {
            toastr.success("<?php echo e(__('voyager::bread.updated_order')); ?>");
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/offer-types/order.blade.php ENDPATH**/ ?>