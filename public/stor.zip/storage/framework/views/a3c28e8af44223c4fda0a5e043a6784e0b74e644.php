<div class="lw--container">
  <div class="nw__topside">
    <span class="nw__title">Ultimii utilizatori </span>
    <a href="/admin/users" class="nw__see">Vezi tot </a>
  </div>
  <span class="nw__bar"></span>
  
  <?php if($top5Users && count($top5Users) > 0): ?>
    <?php $__currentLoopData = $top5Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="nw__details">
        <div> 
           <img class="lw__img" src="<?php echo e(Voyager::image($usr->avatar)); ?>" />
           <a href="admin/users/<?php echo e($usr->id); ?>/edit" class="lw__user--name"><?php echo e($usr->name); ?> - <?php echo e($usr->role->display_name); ?> </a>
        </div>
        <span class="nw__date"> <?php echo e(\Carbon\Carbon::parse($usr->created_at)->format('d F')); ?> </span>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
    Niciun utilizator disponibil
  <?php endif; ?>

</div>
<?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/dashboard-wg/last_users.blade.php ENDPATH**/ ?>