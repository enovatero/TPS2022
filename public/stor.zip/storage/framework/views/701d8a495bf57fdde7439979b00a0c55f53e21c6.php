<div class="adv-json-wrapper">
    <?php
    if(!isset($options->json_fields)) {
        $options->json_fields->key = 'Key';
        $options->json_fields->value = 'Value';
    }
    ?>

    <input id="<?php echo e($row->field); ?>" name="<?php echo e($row->field); ?>" type="hidden" value="<?php echo e($dataTypeContent->{$row->field}); ?>">
    <div id="adv-json-list-<?php echo e($row->field); ?>" class="adv-json-list <?php echo e($row->field); ?>" data-field="<?php echo e($row->field); ?>">

    <?php if($fieldsData = json_decode($dataTypeContent->{$row->field})): ?>
        <?php $__currentLoopData = $fieldsData->rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="adv-json-item">
            <?php $__currentLoopData = $field; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldName => $fieldValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group-line">
                <input type="text" data-master-field="<?php echo e($row->field); ?>" data-field="<?php echo e($fieldName); ?>" data-title="<?php echo e($fieldsData->fields->{$fieldName}); ?>" class="form-control" value="<?php echo e($fieldValue); ?>">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group-line">
                <button data-field="<?php echo e($row->field); ?>" type="button" class="btn btn-danger remove-json"><i class='voyager-x'></i></button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    </div>
    <div class="adv-json-add-holder">
        <div class="adv-json-add-form">
            <?php $__currentLoopData = $options->json_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group-line">
                <label for="<?php echo e($row->field.'-'.$key); ?>"><?php echo e($value); ?> (<?php echo e($key); ?>)</label>
                <input id="<?php echo e($row->field.'-'.$key); ?>" type="text" data-master-field="<?php echo e($row->field); ?>"  data-field="<?php echo e($key); ?>" data-title="<?php echo e($value); ?>" class="form-control">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group-line">
                <button data-field="<?php echo e($row->field); ?>" data-remove="<i class='voyager-x'></i>" type="button" class="btn btn-success add-json"><i class='voyager-list-add'></i></button>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/forge/tps.laravel.touchmediahost.com/vendor/monstrex/voyager-extension/src/../resources/views/formfields/adv_json.blade.php ENDPATH**/ ?>