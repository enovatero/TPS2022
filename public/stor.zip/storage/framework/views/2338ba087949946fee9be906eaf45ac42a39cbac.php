<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<style>
      body{
        font-size: 9pt;
        font-family: "DejaVu Sans";
      }
		p {
			margin: 0;
			font-size:8pt;
		}
		td {
			vertical-align: top;
			font-size:9pt;
		}
		table {
			margin: 1mm 0;
		}
		.items td {
			border: solid 1px slategray;
			padding: 1px 5px;
			font-size: 8pt;
		}
		.item_wborder td {
			border-bottom: solid 2px black !important;
		}
		table thead td {
			background-color: #EEEEEE;
			text-align: center;
			border: 0.1mm solid darkgray;
		}
		.items td.blanktotal {
			background-color: #FFFFFF;
			border: 0mm none #000000;
			border-top: 0.1mm solid #000000;
			border-right: 0.1mm solid #000000;
		}
		.items td.totals {
			text-align: right;
			border: 0.1mm solid darkgray;
		}
		table.items {
			border-collapse: collapse;
			border: 2px solid black;
		}
		h3{
			margin: 2pt 0;
			padding: 2pt 0;
			font-size:10pt;
		}
		.bold {
			font-weight: bold;
		}
    * {
      box-sizing: border-box;
    }
   .row {
      margin-left:-5px;
      margin-right:-5px;
     width: 100%;
    }

    .column {
      width: 100%;
      padding: 5px;
    }
	</style>
</head>
<body>
<?php
    $counter = 1;
    $counter1 = 1;
    $counter2 = 1;
    $twoColumns = false;
    if($offerProducts){
      foreach($offerProducts as $offerProduct){
        if($offerProduct->getParent->category && $offerProduct->getParent->category->two_columns == 1){
          $twoColumns = true;
        }
      }
    }
?>
<table width="100%">
	<tr>
		<td width="48%">
      <p style="font-size: 18pt;">
        <?php echo e($offer->offerType->title); ?>

      </p>
			<p style="font-size: 12pt">
        <strong>Agent</strong>: <?php echo e(Auth::user()->name); ?><br>
      </p>
			<p style="font-size: 12pt">
        <strong>Client</strong>: <?php echo e($offer->client ? $offer->client->name : ''); ?><br><br>
      </p>
      <?php if(!$twoColumns): ?>
        <p style="font-size: 12pt">
          <strong>Observatii</strong><br><?php echo e($offer->observations != null ? ucfirst($offer->observations) : 'Fara observatii'); ?>

        </p>
      <?php endif; ?>
		</td>
		<td width="40%" style="text-align: right; font-size: 18pt">
			Comanda: <b>#<?php echo e($offer->numar_comanda); ?></b>
			<p style="text-align: left; font-size: 12pt">
        <strong>Livrare:</strong> Ridicare personala
      </p>
			<p style="text-align: left; font-size: 12pt">
        <strong>Detalii livrare:</strong> <?php echo e($offer->delivery_details != null ? $offer->delivery_details : '-'); ?>

      </p>
      <?php if(!$twoColumns): ?>
        <p style="text-align: left; font-size: 12pt">
          <strong>Ambalare:</strong> <?php echo e($offer->packing != null ? $offer->packing : '-'); ?>

        </p>
        <?php if($offer->transparent_band == 1): ?>
          <p style="text-align: left; font-size: 12pt">
            <strong>Banda transparenta</strong>
          </p>
        <?php endif; ?>
        <p style="text-align: left; font-size: 12pt">
          <strong>Numar cutii:</strong> <?php echo e($offer->boxes); ?>

        </p>
      <?php endif; ?>
			<p style="text-align: left; font-size: 12pt">
        <strong>Responsabil ambalare:</strong>
      </p>
		</td>
	</tr>
</table>
  <table width="100%">
  <tr>
		<td width="100%" style="text-align: left; font-size: 18pt">
      <?php if($twoColumns): ?>
        <p style="font-size: 12pt">
          <strong>Observatii</strong><br><?php echo e($offer->observations != null ? ucfirst($offer->observations) : 'Fara observatii'); ?>

        </p>
      <?php endif; ?>
		</td>
  </tr>
  </table>
<br><br>
<table width="100%">
	<tr>
		<td width="48%">
			<p style="font-size: 14pt">
        <?php if($attributes && count($attributes)>0): ?>
          <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($attr->attribute->title); ?>: 
            <?php if($attr->attribute->type == 0): ?>
              <?php
                $dim = \App\Dimension::find($attr->col_dim_id);
              ?>
              <strong><?php echo e(strtoupper($dim->value)); ?></strong><br>
            <?php else: ?> 
              <?php
                $col = \App\Color::find($attr->col_dim_id);
              ?>
              <strong><?php echo e(strtoupper($col->ral)); ?></strong><br>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </p>
		</td>
	</tr>
</table>
  
<?php if($twoColumns): ?>
   <?php 
    $newProducts = []; 
    $newProductsLeft = []; 
    $newProductsRight = []; 
   ?>
  
   <?php if($offerProducts): ?>
    <?php $__currentLoopData = $offerProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offerProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($offerProduct->product && $offerProduct->product != null): ?>
        <?php
          if($offerProduct->getParent->category->two_columns == 0){
            array_push($newProductsLeft, [
              'parent' => $offerProduct->getParent,
              'product' => $offerProduct->product,
              'qty'    => $offerProduct->qty,
              'two_columns' => 0,
            ]);
          }
          if($offerProduct->getParent->category->two_columns == 1){
            array_push($newProductsRight, [
              'parent' => $offerProduct->getParent,
              'product' => $offerProduct->product,
              'qty'    => $offerProduct->qty,
              'two_columns' => 1,
            ]);
          }
        ?>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php
      if($newProductsLeft && count($newProductsLeft) > 0 && $newProductsRight && count($newProductsRight) > 0){
          foreach($newProductsLeft as $key => $item){
            if(array_key_exists($key, $newProductsRight)){
              array_push($newProducts, $item);
              array_push($newProducts, $newProductsRight[$key]);
            }else{
              array_push($newProducts, $item);
            }
          }
        }else if($newProductsLeft && count($newProductsLeft) > 0){
          $newProducts = $newProductsLeft;
        }else{
          $newProducts = $newProductsRight;
        }
        $counterLeft = 1;
        $counterRight = 1;
    ?>
  <?php endif; ?>
  <div class="row">
      <div class="column">
        <table class="items" width="100%" cellpadding="1">
        <thead>
        <tr>
          <td width="5%">Nr.<br>crt.</td>
          <td>Denumirea produselor</td>
          <td width="5%">U.M.</td>
          <td width="10%">Cantitate</td>
          <td width="10%" style="border-top: 1px solid #ffffff;border-bottom: 1px solid #ffffff;background-color: #ffffff;"></td>
          <td width="5%">Nr.<br>crt.</td>
          <td>Denumirea produselor</td>
          <td width="5%">U.M.</td>
          <td width="10%">Cantitate</td>
        </tr>
        </thead>
        <tbody>

        <?php if($newProducts): ?>
          <?php $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item['two_columns'] == 1): ?>
              continue;
            <?php else: ?>
              <tr class="items">
                <td align="center"><?php echo e($counterLeft++); ?></td>
                <td><?php echo e($item['product']->name); ?></td>
                <td align="center"><?php echo e($item['parent']->um_title->title); ?></td>
                <td align="center"><?php echo e($item['qty']); ?></td>
                <?php if(array_key_exists($key+1, $newProducts) && $newProducts[$key+1]['two_columns'] == 1): ?>
                  <td align="center" style="border-top: 1px solid #ffffff;border-bottom: 1px solid #ffffff;background-color: #ffffff;"></td>
                  <td align="center"><?php echo e($counterRight++); ?></td>
                  <td><?php echo e($newProducts[$key+1]['product']->name); ?></td>
                  <td align="center"><?php echo e($newProducts[$key+1]['parent']->um_title->title); ?></td>
                  <td align="center"><?php echo e($newProducts[$key+1]['qty']); ?></td>
                <?php else: ?>
                  <td align="center" style="border-top: 1px solid #ffffff;border-bottom: 1px solid #ffffff;background-color: #ffffff;"></td>
                  <td align="center"><?php echo e($counterRight++); ?></td>
                  <td align="center"></td>
                  <td align="center"></td>
                  <td align="center"></td>
                <?php endif; ?>
              </tr>
            <?php endif; ?>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
      </table>
      </div>
  </div>
  
<?php else: ?>
  <table class="items" width="100%" cellpadding="1">
	<thead>
	<tr>
		<td width="5%">Nr.<br>crt.</td>
		<td>Denumirea produselor</td>
		<td width="5%">U.M.</td>
		<td width="10%">Cantitate</td>
	</tr>
	</thead>
	<tbody>
    
  <?php if($offerProducts): ?>
    <?php $__currentLoopData = $offerProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offerProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if($offerProduct->product && $offerProduct->product != null): ?>
          <tr class="items item_wborder">
              <td align="center"><?php echo e($counter++); ?></td>
              <td><?php echo e($offerProduct->product->name); ?></td>
              <td align="center" class="bold"><?php echo e($offerProduct->getParent->um_title->title); ?></td>
              <td align="center" class="bold"><?php echo e($offerProduct->qty); ?></td>
            </tr>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
	</tbody>
</table>

<?php endif; ?>
<div class="row">
  <div class="column">
      <table class="items" width="100%" cellpadding="1">
      <thead>
      <tr>
        <p <?php if($twoColumns): ?> style="font-size: 15pt; width: 100%;text-align:left;" <?php else: ?> style="font-size: 15pt; width: 100%;text-align:right;" <?php endif; ?>><b>Responsabil productie:</b></p>    
        </tr>
        </thead>
      </table>
  </div>
</div>

</body>
</html><?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/pdfs/offer_pdf_order.blade.php ENDPATH**/ ?>