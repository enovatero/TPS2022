<ol class="dd-list">          
   <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="dd-item" data-id="<?php echo e($item->id); ?>">
          <div class="dd-handle" style="height:inherit">
             <span><?php echo e($item->{$display_column}); ?></span>
          </div>
          <?php if(!$item->children->isEmpty()): ?>
              <?php echo $__env->make('voyager::offer-types.suborder', ['items' => $item->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endif; ?>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol><?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/offer-types/suborder.blade.php ENDPATH**/ ?>