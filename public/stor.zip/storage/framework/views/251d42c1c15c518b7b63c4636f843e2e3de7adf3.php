<?php if(old('address', $dataTypeContent->address ?? '') != '' || (isset($addresses) && $addresses && count($addresses) > 0)): ?>
  <?php if(old('address', $dataTypeContent->address ?? '') != ''): ?>
    <?php $__currentLoopData = old('address', $dataTypeContent->address ?? ''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="panel-body container-box-adresa">
          <?php if(!$removeDelete): ?>
            <div class="container-delete-adresa btnDeleteAddress"><span class="voyager-x"></span></div>
          <?php endif; ?>
          <div class="form-group col-md-12 column-element-address">
             <label class="control-label">Introdu adresa(strada, nr, bloc, etaj, ap)</label>
             <input class="control-label" required type="text" name="address[]" data-google-address autocomplete="off" value="<?php echo e(old('address', $dataTypeContent->address ?? '') != '' ? old('address', $dataTypeContent->address)[$key] : ''); ?>"/>                          
          </div>
          <div class="form-group col-md-12 column-element-address">
             <label class="control-label">Tara</label>
                <?php echo $__env->make('vendor.voyager.formfields.countries', ['selected' => old('country', $dataTypeContent->country ?? '') != '' ? old('country', $dataTypeContent->country)[$key] : null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                       
          </div>
          <div class="form-group col-md-12 column-element-address">
             <label class="control-label" for="state">Judet/Regiune</label>
             <select name="state[]" class="form-control select-state" selectedValue="<?php echo e(old('state', $dataTypeContent->state ?? '') != '' ? old('state', $dataTypeContent->state)[$key] : ''); ?>"></select>
          </div>
          <div class="form-group col-md-12 column-element-address">
             <label class="control-label">Oras/Localitate/Sector</label>
             <select name="city[]" class="form-control select-city" selectedValue="<?php echo e(old('city', $dataTypeContent->city ?? '') != '' ? old('city', $dataTypeContent->city)[$key] : ''); ?>"></select>        
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
    <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="panel-body container-box-adresa">
          <input type="hidden" name="ids[]" value="<?php echo e($item->id); ?>"/>
          <?php if(!$removeDelete && $key != 0): ?>
            <div class="container-delete-adresa btnDeleteAddress" idForDelete="<?php echo e($item->id); ?>"><span class="voyager-x"></span></div>
          <?php endif; ?>
          <div class="form-group col-md-12 column-element-address">
             <label class="control-label">Introdu adresa(strada, nr, bloc, etaj, ap)</label>
             <input class="control-label" required type="text" name="address[]" data-google-address autocomplete="off" value="<?php echo e(old('address', $item->address ?? '') != '' ? old('address', $item->address): ''); ?>"/>                          
          </div>
          <div class="form-group col-md-12 column-element-address">
             <label class="control-label">Tara</label>
                <?php echo $__env->make('vendor.voyager.formfields.countries', ['selected' => old('country', $item->country ?? '') != '' ? old('country', $item->country) : null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                       
          </div>
          <div class="form-group col-md-12 column-element-address">
             <label class="control-label" for="state">Judet/Regiune</label>
             <select name="state[]" class="form-control select-state" selectedValue="<?php echo e(old('state', $item->state ?? '') != '' ? old('state', $item->state) : ''); ?>"></select>
          </div>
          <div class="form-group col-md-12 column-element-address">
             <label class="control-label">Oras/Localitate/Sector</label>
             <select name="city[]" class="form-control select-city" selectedValue="<?php echo e(old('city', $item->city ?? '') != '' ? old('city', $item->city) : ''); ?>"></select>        
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
<?php else: ?>
  <div class="panel-body container-box-adresa">
    <?php if(!$removeDelete): ?>
      <div class="container-delete-adresa btnDeleteAddress"><span class="voyager-x"></span></div>
    <?php endif; ?>
    <div class="form-group col-md-12 column-element-address">
       <label class="control-label">Introdu adresa(strada, nr, bloc, etaj, ap)</label>
       <input class="control-label" required type="text" name="address[]" data-google-address autocomplete="off"/>                          
    </div>
    <div class="form-group col-md-12 column-element-address">
       <label class="control-label">Tara</label>
       <?php echo $__env->make('vendor.voyager.formfields.countries', ['selected' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                       
    </div>
    <div class="form-group col-md-12 column-element-address">
       <label class="control-label" for="state">Judet/Regiune</label>
       <select name="state[]" class="form-control select-state"></select>
    </div>
    <div class="form-group col-md-12 column-element-address">
       <label class="control-label">Oras/Localitate/Sector</label>
       <select name="city[]" class="form-control select-city"></select>        
    </div>
  </div>
<?php endif; ?><?php /**PATH /home/forge/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/formfields/address.blade.php ENDPATH**/ ?>