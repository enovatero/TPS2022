<div class="adv-fields-group-wrapper">
    <?php
        if(!$fields = json_decode($dataTypeContent->{$row->field})) {
            $fields = $options;
        }
    ?>
    <?php $__currentLoopData = $fields->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_field => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $value = isset($field->value)? $field->value : "";
        ?>
        <?php if($field->type === 'text'): ?>
            <div class="form-group">
                <label for="<?php echo e($key_field); ?>"><?php echo e($field->label); ?></label>
                <input type="text" id="<?php echo e($key_field); ?>" class="form-control" name="<?php echo e($key_field); ?>" value="<?php echo e($value); ?>">
            </div>
        <?php elseif($field->type === 'number'): ?>
            <div class="form-group">
                <label for="<?php echo e($key_field); ?>"><?php echo e($field->label); ?></label>
                <input type="number" id="<?php echo e($key_field); ?>" class="form-control" name="<?php echo e($key_field); ?>" value="<?php echo e($value); ?>">
            </div>
        <?php elseif($field->type === 'textarea'): ?>
            <div class="form-group">
                <label for="<?php echo e($key_field); ?>"><?php echo e($field->label); ?></label>
                <textarea id="<?php echo e($key_field); ?>" class="form-control" name="<?php echo e($key_field); ?>"><?php echo e($value); ?></textarea>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /home/forge/tps.laravel.touchmediahost.com/vendor/monstrex/voyager-extension/src/../resources/views/formfields/adv_fields_group.blade.php ENDPATH**/ ?>