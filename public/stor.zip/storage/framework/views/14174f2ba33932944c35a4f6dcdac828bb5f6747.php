<?php $__currentLoopData = $offerMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <label class="control-label">
    <?php echo e(\Carbon\Carbon::parse($msg->created_at)->format('Y.m.d - H:i')); ?> --- <strong><?php echo e($msg->user_name); ?></strong> <?php echo $msg->message; ?>

  </label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/partials/log_messages.blade.php ENDPATH**/ ?>