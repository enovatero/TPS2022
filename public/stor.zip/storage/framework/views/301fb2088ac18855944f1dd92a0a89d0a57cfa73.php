<strong>Examples:</strong><br/>
<b>$image</b> = Post-><strong>getFirstMedia(<i>'<?php echo e($gallery); ?>'</i>)</strong>;<br/>
<b>$imageUrl</b> = $image-><strong>getFullUrl()</strong>;<br/>
<b>$imageTitle</b> = $image-><strong>getCustomProperty(<i>'title'</i>)</strong>;<br/>
<b>$imageAlt</b> = $image-><strong>getCustomProperty(<i>'alt'</i>)</strong>;<br/>
<?php /**PATH /home/forge/tps.laravel.touchmediahost.com/vendor/monstrex/voyager-extension/src/../resources/views/formfields/tips/adv_image.blade.php ENDPATH**/ ?>