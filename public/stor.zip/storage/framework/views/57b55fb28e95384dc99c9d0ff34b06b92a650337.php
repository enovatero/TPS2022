<select name="country[]" class="form-control select-country" selectedValue="<?php echo e($selected != null ? $selected : ''); ?>">
  <option value="">Alege...</option>
  <?php
    $countries = json_decode(setting('admin.default_countries'), true);
  ?>
  <?php if($countries && count($countries) > 0): ?>
    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($country['id']); ?>"><?php echo e($country['val']); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</select>   <?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/formfields/countries.blade.php ENDPATH**/ ?>