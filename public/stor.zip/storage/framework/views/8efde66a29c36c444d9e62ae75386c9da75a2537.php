

<div class="middle__container">
<?php echo $__env->make('vendor.voyager.dashboard-wg.calendar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('vendor.voyager.dashboard-wg.last_users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('vendor.voyager.dashboard-wg.profit_chart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div><?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/dashboard-wg/middle.blade.php ENDPATH**/ ?>