<ol class="dd-list">

<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li class="dd-item" data-id="<?php echo e($item->id); ?> <?php if(!$item->status): ?> unpublished-record <?php endif; ?>">
        <div class="pull-right item_actions">
            <div class="btn btn-sm btn-danger pull-right delete" data-id="<?php echo e($item->id); ?>">
                <i class="voyager-trash"></i> <?php echo e(__('voyager::generic.delete')); ?>

            </div>
            <div class="btn btn-sm btn-primary pull-right edit"
                data-id="<?php echo e($item->id); ?>"
                data-title="<?php echo e($item->title); ?>"
                data-url="<?php echo e($item->url); ?>"
                data-target="<?php echo e($item->target); ?>"
                data-icon_class="<?php echo e($item->icon_class); ?>"
                data-color="<?php echo e($item->color); ?>"
                data-route="<?php echo e($item->route); ?>"
                data-parameters="<?php echo e(json_encode($item->parameters)); ?>"
            >
                <i class="voyager-edit"></i> <?php echo e(__('voyager::generic.edit')); ?>

            </div>
        </div>
        <div class="dd-handle admin-menu-title">
            <?php if($options->isModelTranslatable): ?>
                <?php echo $__env->make('voyager::multilingual.input-hidden', [
                    'isModelTranslatable' => true,
                    '_field_name'         => 'title'.$item->id,
                    '_field_trans'        => json_encode($item->getTranslationsOf('title'))
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <span><?php echo e($item->title); ?></span> <small class="url"><?php echo e($item->link()); ?></small>
        </div>
        <div class="dd-admin-checkbox">
            <span class="tree-admin-status">
                <input type="checkbox" data-slug="menu-items" data-id="<?php echo e($item->id); ?>" name="status" <?php if($item->status): ?> checked <?php endif; ?> class="tiny-toggle" data-tt-type="dot" data-tt-size="tiny">
            </span>
        </div>

    <?php if(!$item->children->isEmpty()): ?>
            <?php echo $__env->make('voyager-extension::menu.admin', ['items' => $item->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ol>
<?php /**PATH /home/forge/tps.laravel.touchmediahost.com/vendor/monstrex/voyager-extension/src/../resources/views/menu/admin.blade.php ENDPATH**/ ?>