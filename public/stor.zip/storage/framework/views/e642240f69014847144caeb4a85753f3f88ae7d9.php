<div class="nw--container">
  <div class="nw__topside">
    <span class="nw__title">Cele mai noi comenzi </span>
    <a href="/admin/offers?sort_order=desc&order_by=serie" class="nw__see">Vezi tot </a>
  </div>
  <span class="nw__bar"></span>
  <?php if($top5Orders && count($top5Orders) > 0): ?>
    <?php $__currentLoopData = $top5Orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="nw__details">
        <a href="/admin/offers/<?php echo e($order->id); ?>/edit" class="nw__orderNr"><?php echo e($order->serie != null ? $order->serie : '-'); ?></a>
        <span class="nw__clientName"><?php echo e($order->client->name ?? ''); ?></span>
        <span class="nw__price"> <?php echo e(number_format($order->total_final, 2, '.', '')); ?> RON </span>
        <span class="nw__date"> <?php echo e(\Carbon\Carbon::parse($order->offer_date)->format('d F')); ?> </span>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
    Nicio comanda disponibila
  <?php endif; ?>

</div>
<?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/dashboard-wg/newest_orders.blade.php ENDPATH**/ ?>