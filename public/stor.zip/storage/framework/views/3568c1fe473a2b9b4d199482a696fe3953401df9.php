<?php
    $treeMode = false;
    foreach($dataType->browseRows as $row) {
        if($row->field === 'parent_id') {
            $treeMode = isset($row->details->browse_tree);
        }
    }
?>

<?php if($treeMode): ?>
    <?php echo $__env->make('voyager-extension::bread.browse-tree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('voyager-extension::bread.browse-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /home/forge/tps.laravel.touchmediahost.com/vendor/monstrex/voyager-extension/src/../resources/views/bread/browse.blade.php ENDPATH**/ ?>