<?php
  $cleanRulePrices = $priceRules;
  $totalCalculat = 0;
  $totalCalculatPi = 0;
  foreach($priceRules as $rule){
    $totalCalculatRules[$rule->id] = 0;
  }
?>
<div class="box-body table-responsive no-padding table-prices">
  <input name="selectedProducts" class="selectedProducts" type="hidden"/>
  <table class="table table-hover items">
    <tbody>
      <tr>
        <th></th>
        <th style="font-weight: bold;">Denumire produs</th>
        <th style="text-align:center;font-weight: bold;">U.M.</th>
        <th style="text-align:center;font-weight: bold;">Cantitate</th>
        <th style="text-align:right;font-weight: bold;">EUR <br>fara TVA </th>
        <th style="text-align:right;font-weight: bold;">RON <br>cu TVA </th>
        <th style="text-align:right;font-weight: bold;">RON <br>TOTAL </th>
        <th></th>
        <th style="text-align:right;font-weight: bold;">PI</th>
        <?php $__currentLoopData = $cleanRulePrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <th style="text-align:right;font-weight: bold;"><?php echo e($rule->title); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tr>
      <?php if($parents != null): ?>
        <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr parent_id="<?php echo e($parent->id); ?>">
            <?php
              $parent->offerProducts = \App\OfferProduct::where('parent_id', $parent->id)->where('offer_id', $offer->id)->first();
            ?>
            <?php if($parent->offerProducts != null): ?> 
              <input type="hidden" name="offerProductIds[]" value="<?php echo e($parent->offerProducts->id); ?>"/>
            <?php endif; ?>
            <?php
              if($parent->offerProducts != null && $parent->offerProducts->prices != null){
                $checkRule = $parent->offerProducts->prices->filter(function($item) use($offer){
                    return $item->rule_id == $offer->price_grid_id;
                })->first();
                $eurFaraTVA = $checkRule != null ? $checkRule->eur_fara_tva : 0;
                $ronCuTVA = $checkRule != null ? $checkRule->ron_cu_tva : 0;
                $ronTotal = $ronCuTVA*$parent->offerProducts->qty;
                $totalCalculat += $ronTotal;
                $totalCalculatPi += $checkRule != null ? $checkRule->base_price : 0;
              } else{
                $checkRule = null;
                $eurFaraTVA = 0;
                $ronCuTVA = 0;
                $ronTotal = 0;
              }
            ?>
            <td>
              <?php echo e($key+1); ?>

            </td>
            <td style="text-align: left;"> <?php echo e($parent->title); ?></td>
            <td style="text-align:center"><?php echo e($parent->um_title->title); ?></td>
            <td style="text-align:center">
              <input type="number"  <?php if($parent->offerProducts != null): ?> name="offerQty[]" value="<?php echo e($parent->offerProducts->qty); ?>" <?php else: ?> readonly <?php endif; ?> autocomplete="off" class="form-control input-sm changeQty parentId-<?php echo e($parent->id); ?>" parentId="<?php echo e($parent->id); ?>" style="width: 70px; display:inline">
            </td>
            <td style="text-align:center;">
              <input readonly type="number" autocomplete="off" class="form-control input-sm eurFaraTVA parent-<?php echo e($parent->id); ?>" style="width: 70px; display:inline; cursor: not-allowed;" <?php if($eurFaraTVA != 0): ?> value="<?php echo e($eurFaraTVA); ?>" <?php else: ?> value="0.00" <?php endif; ?>>
            </td>
            <td style="text-align:center;">
              <input readonly type="number" class="form-control input-sm ronCuTVA parent-<?php echo e($parent->id); ?>" style="width: 70px; display:inline; cursor: not-allowed;" <?php if($ronCuTVA != 0): ?> value="<?php echo e($ronCuTVA); ?>" <?php else: ?> value="0.00" <?php endif; ?>>
            </td>
            <td style="text-align:center;">
              <input readonly type="number" class="form-control input-sm ronTotal parent-<?php echo e($parent->id); ?>" style="width: 70px; display:inline; cursor: not-allowed;" <?php if($ronCuTVA != 0): ?> value="<?php echo e($ronTotal); ?>" <?php else: ?> value="0.00" <?php endif; ?>>
            </td>
            <td style="background: lightgrey"></td>
            <td style="text-align: center;">
              <input class="pret-intrare parent-<?php echo e($parent->id); ?>" type="hidden"/>
              <?php if($checkRule != null): ?>
                <span class="pretIntrare parent-<?php echo e($parent->id); ?>"><?php echo e($checkRule->base_price); ?></span>
              <?php else: ?>
                <span class="pretIntrare parent-<?php echo e($parent->id); ?>">0.00</span>
              <?php endif; ?>
            </td>
            <?php if($parent->offerProducts != null && $parent->offerProducts->prices != null): ?>
              <?php $__currentLoopData = $parent->offerProducts->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $subtotalRule = $parent->offerProducts->qty*$rule->ron_cu_tva;
                  $totalCalculatRules[$rule->rule_id] += $subtotalRule;
                ?>
                  <td style="text-align: center;">
                    <input class="baseParent-<?php echo e($parent->id); ?> baseRule-<?php echo e($rule->rule_id); ?> inputBaseRule" parent_id="<?php echo e($parent->id); ?>" base_rule_id="<?php echo e($rule->rule_id); ?>" type="hidden" display="none"/>
                    <span class="parent-<?php echo e($parent->id); ?> baseRule-<?php echo e($rule->rule_id); ?>"><?php echo e($subtotalRule); ?></span>
                  </td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if(count($cleanRulePrices) > count($parent->offerProducts->prices)): ?>
                <td style="text-align: center;">
                  <input class="baseParent-<?php echo e($parent->id); ?> inputBaseRule" parent_id="<?php echo e($parent->id); ?>" type="hidden" display="none"/>
                  <span class="parent-<?php echo e($parent->id); ?>">0.00</span>
                </td>
              <?php endif; ?>
            <?php else: ?>
              <?php $__currentLoopData = $cleanRulePrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td style="text-align: center;">
                  <input class="baseParent-<?php echo e($parent->id); ?> baseRule-<?php echo e($rule->id); ?> inputBaseRule" parent_id="<?php echo e($parent->id); ?>" base_rule_id="<?php echo e($rule->id); ?>" type="hidden" display="none"/>
                  <span class="parent-<?php echo e($parent->id); ?> baseRule-<?php echo e($rule->id); ?>">0.00</span>
                </td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <input style="display: none;" type="hidden" name="parentIds[]" value="<?php echo e($parent->id); ?>"/>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>

      <tr class="total">
        <td colspan="6" class="totals" style="text-align: right;font-weight: bold;">
          <b style="font-weight: bold;">Total general cu TVA inclus - RON -</b>
        </td>
        <td class="totals"><b><span class="totalGeneralCuTva" style="font-weight: bold;"><?php echo e($totalCalculat != 0 ? $totalCalculat : '0.00'); ?></span></b><input name="totalGeneral" type="hidden" value="<?php echo e($totalCalculat != 0 ? $totalCalculat : '0.00'); ?>"></td>
        <td style="background: lightgrey"></td>
        <td style="text-align: center;font-weight: bold;"><span class="totalPricePi"><?php echo e($totalCalculatPi != 0 ? $totalCalculatPi : '0.00'); ?></span></td>
        <?php $__currentLoopData = $cleanRulePrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <td style="text-align: center;"><span class="totalPrice<?php echo e($rule->id); ?>"><?php echo e(array_key_exists($rule->id, $totalCalculatRules) && $totalCalculatRules[$rule->id] != 0 ? $totalCalculatRules[$rule->id] : '0.00'); ?></span></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tr>
      <tr class="total">
        <td colspan="6" class="totals" style="text-align: right;font-weight: bold;"><b style="font-weight: bold;">Reducere - RON -</b></td>
        <td class="totals"><b><span class="reducereRon" style="font-weight: bold;"><?php echo e($reducere != null || $reducere != 0 ? number_format($reducere, 2) : '0.00'); ?></span></b><input name="reducere" type="hidden" value="<?php echo e(number_format($reducere, 2)); ?>"></td>
        <td style="background: lightgrey"></td>
        <th style="text-align:right;font-weight: bold;">PI</th>
        <?php $__currentLoopData = $cleanRulePrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <th style="text-align:right;font-weight: bold;"><?php echo e($rule->title); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tr>
      <tr class="total">
        <td colspan="6" class="totals" style="text-align: right;"><b style="font-weight: bold;">Total final - RON -</b></td>
        <td class="totals">
          <input type="number" class="totalHandled" class="form-control" style="width: 100px; float: right; text-align: right" name="totalCalculatedPrice" value="<?php echo e($totalCalculat != 0 ? number_format($totalCalculat - $reducere, 2) : '0.00'); ?>">
          <b style="display: none !important;"><span class="totalFinalRon" style="font-weight: bold;"><?php echo e($totalCalculat != 0 ? $totalCalculat : '0.00'); ?></span></b>
          <input name="totalFinal" type="hidden">
        </td>
      </tr>
<!--       <tr class="totals">
        <td colspan="7" class="totals"><input type="number" class="totalHandled" class="form-control" style="width: 100px; float: right; text-align: right" name="totalCalculatedPrice"></td>
      </tr> -->
    </tbody>
  </table>
</div><?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/products/offer_box.blade.php ENDPATH**/ ?>