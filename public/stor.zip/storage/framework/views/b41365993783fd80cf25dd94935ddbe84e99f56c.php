<?php if(config('voyager.show_dev_tips')): ?>
<div class="field-helper">
    <?php if ($__env->exists('voyager-extension::formfields.tips.adv_image', ['gallery' => $row->field])) echo $__env->make('voyager-extension::formfields.tips.adv_image', ['gallery' => $row->field], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php endif; ?>

<?php if($adv_image = $dataTypeContent->getFirstMedia($row->field)): ?>
<div class="adv-image-wrapper">
    <div class="adv-image"
         data-type="<?php echo e($row->type); ?>"
         data-model="<?php echo e($dataType->model_name); ?>"
         data-slug="<?php echo e($dataType->slug); ?>"
         data-field-name="<?php echo e($row->field); ?>"
         data-file-name="<?php echo e($adv_image->file_name); ?>"
         data-id="<?php echo e($dataTypeContent->id); ?>"
         data-image-id="<?php echo e($adv_image->id); ?>">

        <img class="" src="<?php echo e($adv_image->getFullUrl()); ?>">
        <div class="adv-image-fields">
            <div class="adv-image-field adv-image-file">
                <span class="adv-image-file-title"><?php echo app('translator')->get('voyager-extension::bread.adv_image.file'); ?></span>
                <span class="adv-image-file-name"><?php echo e(Str::limit($adv_image->file_name, 30, ' (...)')); ?></span>
                <span class="adv-image-file-size <?php if($adv_image->size > 100000): ?> large <?php endif; ?>"><?php echo e($adv_image->human_readable_size); ?></span>
            </div>
            <div class="adv-image-field">
                <label class="control-label" for="<?php echo e($row->field); ?>_title"><?php echo app('translator')->get('voyager-extension::bread.adv_image.title'); ?></label>
                <input type="text" class="form-control" name="<?php echo e($row->field); ?>_title"
                       placeholder="Image Title"
                       value="<?php echo e($adv_image->getCustomProperty('title')); ?>">
            </div>
            <div class="adv-image-field">
                <label class="control-label" for="<?php echo e($row->field); ?>_alt"><?php echo app('translator')->get('voyager-extension::bread.adv_image.alt'); ?></label>
                <input type="text" class="form-control" name="<?php echo e($row->field); ?>_alt"
                       placeholder="Image Alt"
                       value="<?php echo e($adv_image->getCustomProperty('alt')); ?>">
            </div>
        </div>
        <a href="javascript:;" title="Удалить" class="btn btn-sm btn-danger single-adv-image-remove">
            <i class="voyager-trash"></i> <span class="hidden-xs hidden-sm"><?php echo app('translator')->get('voyager-extension::bread.adv_image.delete'); ?></span>
        </a>
    </div>
</div>
<?php endif; ?>
<input <?php if($row->required == 1 && !isset($dataTypeContent->{$row->field})): ?> required <?php endif; ?> type="file" name="<?php echo e($row->field); ?>" accept="image/*">

<?php /**PATH /home/forge/tps.laravel.touchmediahost.com/vendor/monstrex/voyager-extension/src/../resources/views/formfields/adv_image.blade.php ENDPATH**/ ?>