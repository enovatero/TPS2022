<?php $__currentLoopData = $offerEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <label class="control-label">
    <?php echo e(\Carbon\Carbon::parse($event->created_at)->format('Y.m.d - H:i')); ?> --- <strong><?php echo e($event->user_name); ?></strong> <?php echo $event->message; ?>

  </label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/tmedia/tps.laravel.touchmediahost.com/resources/views/vendor/voyager/partials/log_events.blade.php ENDPATH**/ ?>