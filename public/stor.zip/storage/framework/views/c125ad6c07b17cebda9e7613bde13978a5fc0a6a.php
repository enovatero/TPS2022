<?php $__env->startSection('page_title', __('voyager::generic.viewing').' '.$dataType->getTranslatedAttribute('display_name_plural')); ?>

<?php $__env->startSection('page_header'); ?>
    <div class="container-fluid">
        <h1 class="page-title">
            <i class="<?php echo e($dataType->icon); ?>"></i> <?php echo e($dataType->getTranslatedAttribute('display_name_plural')); ?>

        </h1>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add', app($dataType->model_name))): ?>
            <a href="<?php echo e(route('voyager.'.$dataType->slug.'.create')); ?>" class="btn btn-success btn-add-new">
                <i class="voyager-plus"></i> <span><?php echo e(__('voyager::generic.add_new')); ?></span>
            </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', app($dataType->model_name))): ?>
            <?php echo $__env->make('voyager::partials.bulk-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', app($dataType->model_name))): ?>
            <?php if(isset($dataType->order_column) && isset($dataType->order_display_column)): ?>
                <a href="<?php echo e(route('voyager.'.$dataType->slug.'.order')); ?>" class="btn btn-primary btn-add-new">
                    <i class="voyager-list"></i> <span><?php echo e(__('voyager::bread.order')); ?></span>
                </a>
            <?php endif; ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', app($dataType->model_name))): ?>
            <?php if($usesSoftDeletes): ?>
                <input type="checkbox" <?php if($showSoftDeleted): ?> checked <?php endif; ?> id="show_soft_deletes" data-toggle="toggle" data-on="<?php echo e(__('voyager::bread.soft_deletes_off')); ?>" data-off="<?php echo e(__('voyager::bread.soft_deletes_on')); ?>">
            <?php endif; ?>
        <?php endif; ?>
        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(method_exists($action, 'massAction')): ?>
                <?php echo $__env->make('voyager::bread.partials.actions', ['action' => $action, 'data' => null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php

            $model_filters = [];
            foreach($dataType->browseRows as $row) {
                if(isset($row->details->browse_filter)) {
                    $model_filters[] = [
                        'filter_items' => buildFlatFromTree(flat_to_tree(app($row->details->model)->get()->toArray())),
                        'filter_title' => $row->display_name,
                        'filter_column' => $row->details->column,
                        'filter_key' => $row->details->key,
                        'filter_label' => $row->details->label,
                    ];
                }
            }
        ?>

        <?php if(count($model_filters) > 0): ?>
            <div class="browse-filters-holder" data-url="<?php echo e(Request::url()); ?>">
                <?php $__currentLoopData = $model_filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="filter-selector">
                <label for="filter-selector-<?php echo e($key); ?>"><?php echo e($filter['filter_title']); ?>:</label>
                <select id="filter-selector-<?php echo e($key); ?>" name="filter-selector[]" data-column="<?php echo e($filter['filter_column']); ?>" class="filter-select select2">
                    <option value="">---</option>

                    <?php
                        $val = null;
                        if ($filters) {
                            foreach ($filters['field'] as $idx => $field) {
                                $val = $field === $filter['filter_column']? $val = $filters['value'][$idx] : $val;
                            }
                        }
                    ?>

                    <?php $__currentLoopData = $filter['filter_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item['id']); ?>" <?php if($val && $item['id'] == $val): ?> selected <?php endif; ?>>
                        <?php if($item['level'] > 0): ?> <?php echo e(str_repeat("--", $item['level'])); ?> <?php endif; ?> <?php echo e($item[$filter['filter_label']]); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php echo $__env->make('voyager::multilingual.language-selector', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php
    // Set specified columns order
    $dataType->browseRows = $dataType->browseRows->sortBy(function ($row, $key) {
        return isset($row->details->browse_order)? $row->details->browse_order : 0;
    });
    // Correct Index Column for sorting in the table
    $orderColumn[0][0] = $dataType->browseRows->pluck('field')->search($orderBy) + ($showCheckboxColumn ? 1 : 0);
?>

<?php $__env->startSection('content'); ?>
    <div class="page-content browse container-fluid vext-browse">
        <?php echo $__env->make('voyager::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-body">
                        <?php if($isServerSide): ?>
                            <form method="get" class="form-search">

                                <div id="search-input">
                                    <div class="col-2">
                                        <select id="search_key" name="key">
                                            <?php $__currentLoopData = $searchNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if($search->key == $key || (empty($search->key) && $key == $defaultSearchKey)): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-2">
                                        <select id="filter" name="filter">
                                            <option value="contains" <?php if($search->filter == "contains"): ?> selected <?php endif; ?>>contains</option>
                                            <option value="equals" <?php if($search->filter == "equals"): ?> selected <?php endif; ?>>=</option>
                                        </select>
                                    </div>
                                    <div class="input-group col-md-12">
                                        <input type="text" class="form-control" placeholder="<?php echo e(__('voyager::generic.search')); ?>" name="s" value="<?php echo e($search->value); ?>">
                                        <span class="input-group-btn">
                                            <button class="btn btn-info btn-lg" type="submit">
                                                <i class="voyager-search"></i>
                                            </button>
                                        </span>
                                    </div>
                                </div>

                                <?php if(Request::has('sort_order') && Request::has('order_by')): ?>
                                    <input type="hidden" name="sort_order" value="<?php echo e(Request::get('sort_order')); ?>">
                                    <input type="hidden" name="order_by" value="<?php echo e(Request::get('order_by')); ?>">
                                <?php endif; ?>
                            </form>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-hover">
                                <thead>
                                    <tr>
                                        <?php if($showCheckboxColumn): ?>
                                            <th>
                                                <input type="checkbox" class="select_all">
                                            </th>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $dataType->browseRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="<?php if(isset($row->details->browse_align)): ?><?php echo e($row->details->browse_align); ?><?php endif; ?>"
                                            <?php if(isset($row->details->browse_width)): ?> style="width:<?php echo e($row->details->browse_width); ?>"<?php endif; ?>>
                                            <?php if($isServerSide): ?>
                                                <a href="<?php echo e($row->sortByUrl($orderBy, $sortOrder)); ?>">
                                            <?php endif; ?>

                                            <?php if(isset($row->details->browse_title)): ?>
                                                <?php echo e($row->details->browse_title); ?>

                                            <?php else: ?>
                                                <?php echo e($row->getTranslatedAttribute('display_name')); ?>

                                            <?php endif; ?>

                                            <?php if($isServerSide): ?>
                                                <?php if($row->isCurrentSortField($orderBy)): ?>
                                                    <?php if($sortOrder == 'asc'): ?>
                                                        <i class="voyager-angle-up pull-right"></i>
                                                    <?php else: ?>
                                                        <i class="voyager-angle-down pull-right"></i>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                </a>
                                            <?php endif; ?>
                                        </th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <th class="actions text-right"><?php echo e(__('voyager::generic.actions')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $dataTypeContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-record-id="<?php echo e($data->getKey()); ?>"
                                        data-slug="<?php echo e($dataType->slug); ?>"
                                        class="<?php echo e(isset($data->status) && (int)$data->status === 0? 'unpublished-record' : ''); ?> <?php if($dataType->server_side): ?><?php echo e($loop->index % 2 === 0? 'odd' : 'even'); ?><?php endif; ?>">
                                        <?php if($showCheckboxColumn): ?>
                                            <td>
                                                <input type="checkbox" name="row_id" id="checkbox_<?php echo e($data->getKey()); ?>" value="<?php echo e($data->getKey()); ?>">
                                            </td>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $dataType->browseRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            if ($data->{$row->field.'_browse'}) {
                                                $data->{$row->field} = $data->{$row->field.'_browse'};
                                            }
                                            ?>
                                            <td class="<?php if(isset($row->details->browse_align)): ?><?php echo e($row->details->browse_align); ?><?php endif; ?>"
                                                <?php if(isset($row->details->browse_font_size)): ?> style="font-size:<?php echo e($row->details->browse_font_size); ?>"<?php endif; ?>>

                                                <?php if(isset($row->details->view)): ?>
                                                    <?php echo $__env->make($row->details->view, ['row' => $row, 'dataType' => $dataType, 'dataTypeContent' => $dataTypeContent, 'content' => $data->{$row->field}, 'action' => 'browse', 'view' => 'browse', 'options' => $row->details], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                
                                                <?php elseif($row->type == 'image'): ?>
                                                    <img src="<?php if( !filter_var($data->{$row->field}, FILTER_VALIDATE_URL)): ?><?php echo e(Voyager::image( $data->{$row->field} )); ?><?php else: ?><?php echo e($data->{$row->field}); ?><?php endif; ?>" style="height: 50px; width:auto">

                                                
                                                <?php elseif($row->type == 'adv_image'): ?>
                                                    <?php if($adv_image = $data->getFirstMedia($row->field)): ?>
                                                        <img src="<?php echo e($adv_image->getFullUrl()); ?>" style="height: <?php echo e($row->details->browse_image_max_height?? '50px'); ?>; width:auto">
                                                    <?php endif; ?>

                                                
                                                <?php elseif($row->type == 'adv_media_files'): ?>
                                                    <?php if($adv_media_files = $data->getMedia($row->field)->take(3)): ?>
                                                        <?php $__currentLoopData = $adv_media_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $adv_file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(explode('/', $adv_file->mime_type)[0] === 'image'): ?>
                                                                <img src="<?php echo e($adv_file->getFullUrl()); ?>" style="height: <?php echo e($row->details->browse_image_max_height?? '50px'); ?>; width:auto" >
                                                            <?php else: ?>
                                                                <a href="<?php echo e($adv_file->getFullUrl()); ?>">
                                                                    <img class="file-type" src="<?php echo e(voyager_extension_asset('icons/files/'.explode('/', $adv_file->mime_type)[1].'.svg')); ?>" style="height: <?php echo e($row->details->browse_image_max_height?? '20px'); ?>; width:auto">
                                                                </a>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>

                                                
                                                <?php elseif($row->type == 'relationship'): ?>
                                                    <?php echo $__env->make('voyager::formfields.relationship', ['view' => 'browse','options' => $row->details], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                
                                                <?php elseif($row->type == 'select_multiple'): ?>
                                                    <?php if(property_exists($row->details, 'relationship')): ?>
                                                        <?php $__currentLoopData = $data->{$row->field}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($item->{$row->field}); ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif(property_exists($row->details, 'options')): ?>
                                                        <?php if(!empty(json_decode($data->{$row->field}))): ?>
                                                            <?php $__currentLoopData = json_decode($data->{$row->field}); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(@$row->details->options->{$item}): ?>
                                                                    <?php echo e($row->details->options->{$item} . (!$loop->last ? ', ' : '')); ?>

                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <?php echo e(__('voyager::generic.none')); ?>

                                                        <?php endif; ?>
                                                    <?php endif; ?>

                                                
                                                <?php elseif($row->type == 'multiple_checkbox' && property_exists($row->details, 'options')): ?>
                                                    <?php if(@count(json_decode($data->{$row->field})) > 0): ?>
                                                        <?php $__currentLoopData = json_decode($data->{$row->field}); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(@$row->details->options->{$item}): ?>
                                                                <?php echo e($row->details->options->{$item} . (!$loop->last ? ', ' : '')); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php echo e(__('voyager::generic.none')); ?>

                                                    <?php endif; ?>

                                                
                                                <?php elseif(($row->type == 'select_dropdown' || $row->type == 'radio_btn') && property_exists($row->details, 'options')): ?>
                                                    <?php echo $row->details->options->{$data->{$row->field}} ?? ''; ?>


                                                
                                                <?php elseif(($row->type == 'adv_select_dropdown_tree')): ?>
                                                    <?php if(!empty($data->{$row->field})): ?>
                                                    <span class="browse-dropdown-title">
                                                        <span class="label label-info">
                                                        <?php echo e($data->{$row->details->relationship->field}[$row->details->relationship->label]); ?>

                                                        </span>
                                                    </span>
                                                    <?php endif; ?>

                                                
                                                <?php elseif($row->type == 'date' || $row->type == 'timestamp'): ?>
                                                    <?php if( property_exists($row->details, 'format') && !is_null($data->{$row->field}) ): ?>
                                                        <?php echo e(\Carbon\Carbon::parse($data->{$row->field})->formatLocalized($row->details->format)); ?>

                                                    <?php else: ?>
                                                        <?php echo e($data->{$row->field}); ?>

                                                    <?php endif; ?>

                                                
                                                <?php elseif($row->type == 'checkbox'): ?>
                                                    <?php if(property_exists($row->details, 'on') && property_exists($row->details, 'off')): ?>
                                                        <?php if(property_exists($row->details, 'browse_inline_checkbox') || property_exists($row->details, 'browse_inline_editor')): ?>
                                                            <input type="checkbox" data-id="<?php echo e($data->id); ?>" name="<?php echo e($row->field); ?>" <?php if($data->{$row->field}): ?> checked <?php endif; ?> class="tiny-toggle" data-tt-type="dot" data-tt-size="tiny">
                                                        <?php else: ?>
                                                            <?php if($data->{$row->field}): ?>
                                                            <span class="label label-info"><?php echo e($row->details->on); ?></span>
                                                            <?php else: ?>
                                                            <span class="label label-primary"><?php echo e($row->details->off); ?></span>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                    <?php echo e($data->{$row->field}); ?>

                                                    <?php endif; ?>

                                                
                                                <?php elseif($row->type == 'color'): ?>
                                                    <span class="badge badge-md" style="background-color: <?php echo e($data->{$row->field}); ?>"><?php echo e($data->{$row->field}); ?></span>

                                                
                                                <?php elseif($row->type == 'text' || $row->type == 'number'): ?>
                                                    <?php echo $__env->make('voyager::multilingual.input-hidden-bread-browse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <div class="text-field-holder">
                                                        <?php if(isset($row->details->browse_inline_editor)): ?>
                                                        <div class="browse-inline-editor">
                                                            <input class="browse-inline-input" data-id="<?php echo e($data->id); ?>" <?php if($row->type == 'number'): ?> type="number" <?php else: ?> type="text" <?php endif; ?> name="<?php echo e($row->field); ?>" value="<?php echo e($data->{$row->field}); ?>">
                                                            <button class="text-inline-save" type="button" title="<?php echo app('translator')->get('voyager-extension::bread.inline_save'); ?>"><i class="voyager-check"></i></button>
                                                            <button class="text-inline-cancel" type="button" title="<?php echo app('translator')->get('voyager-extension::bread.inline_cancel'); ?>"><i class="voyager-x"></i></button>
                                                        </div>
                                                        <?php endif; ?>
                                                        <div class="browse-text-holder">
                                                            <?php if(isset($row->details->url)): ?>
                                                            <a href="<?php echo e(route('voyager.'.$dataType->slug.'.'.$row->details->url, $data->{$data->getKeyName()})); ?>">
                                                            <?php elseif(isset($row->details->route) && isset($row->details->route->name) && isset($row->details->route->param_field)): ?>
                                                            <a href="<?php echo e(route($row->details->route->name, $data->{$row->details->route->param_field})); ?>">
                                                            <?php endif; ?>
                                                                <div><?php echo e(mb_strlen( $data->{$row->field} ) > 200 ? mb_substr($data->{$row->field}, 0, 200) . ' ...' : $data->{$row->field}); ?></div>
                                                            <?php if(isset($row->details->url)): ?>
                                                            </a>
                                                            <?php endif; ?>
                                                            <?php if(isset($row->details->browse_inline_editor)): ?>
                                                            <button class="text-inline-edit" type="button" title="<?php echo app('translator')->get('voyager-extension::bread.inline_edit'); ?>"><i class="voyager-edit"></i></button>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                
                                                <?php elseif($row->type == 'text_area'): ?>
                                                    <?php echo $__env->make('voyager::multilingual.input-hidden-bread-browse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <div><?php echo e(mb_strlen( $data->{$row->field} ) > 200 ? mb_substr($data->{$row->field}, 0, 200) . ' ...' : $data->{$row->field}); ?></div>

                                                
                                                <?php elseif($row->type == 'file' && !empty($data->{$row->field}) ): ?>
                                                    <?php echo $__env->make('voyager::multilingual.input-hidden-bread-browse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <?php if(json_decode($data->{$row->field}) !== null): ?>
                                                        <?php $__currentLoopData = json_decode($data->{$row->field}); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a href="<?php echo e(Storage::disk(config('voyager.storage.disk'))->url($file->download_link) ?: ''); ?>" target="_blank">
                                                                <?php echo e($file->original_name ?: ''); ?>

                                                            </a>
                                                            <br/>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(Storage::disk(config('voyager.storage.disk'))->url($data->{$row->field})); ?>" target="_blank">
                                                            Download
                                                        </a>
                                                    <?php endif; ?>

                                                
                                                <?php elseif($row->type == 'rich_text_box'): ?>
                                                    <?php echo $__env->make('voyager::multilingual.input-hidden-bread-browse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <div><?php echo e(mb_strlen( strip_tags($data->{$row->field}, '<b><i><u>') ) > 200 ? mb_substr(strip_tags($data->{$row->field}, '<b><i><u>'), 0, 200) . ' ...' : strip_tags($data->{$row->field}, '<b><i><u>')); ?></div>

                                                
                                                <?php elseif($row->type == 'coordinates'): ?>
                                                    <?php echo $__env->make('voyager::partials.coordinates-static-image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                
                                                <?php elseif($row->type == 'multiple_images'): ?>
                                                    <?php $images = json_decode($data->{$row->field}); ?>
                                                    <?php if($images): ?>
                                                        <?php $images = array_slice($images, 0, 3); ?>
                                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <img src="<?php if( !filter_var($image, FILTER_VALIDATE_URL)): ?><?php echo e(Voyager::image( $image )); ?><?php else: ?><?php echo e($image); ?><?php endif; ?>" style="width:50px">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>

                                                
                                                <?php elseif($row->type == 'media_picker'): ?>
                                                    <?php
                                                        if (is_array($data->{$row->field})) {
                                                            $files = $data->{$row->field};
                                                        } else {
                                                            $files = json_decode($data->{$row->field});
                                                        }
                                                    ?>
                                                    <?php if($files): ?>
                                                        <?php if(property_exists($row->details, 'show_as_images') && $row->details->show_as_images): ?>
                                                            <?php $__currentLoopData = array_slice($files, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <img src="<?php if( !filter_var($file, FILTER_VALIDATE_URL)): ?><?php echo e(Voyager::image( $file )); ?><?php else: ?><?php echo e($file); ?><?php endif; ?>" style="width:50px">
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <ul>
                                                            <?php $__currentLoopData = array_slice($files, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><?php echo e($file); ?></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        <?php endif; ?>
                                                        <?php if(count($files) > 3): ?>
                                                            <?php echo e(__('voyager::media.files_more', ['count' => (count($files) - 3)])); ?>

                                                        <?php endif; ?>
                                                    <?php elseif(is_array($files) && count($files) == 0): ?>
                                                        <?php echo e(trans_choice('voyager::media.files', 0)); ?>

                                                    <?php elseif($data->{$row->field} != ''): ?>
                                                        <?php if(property_exists($row->details, 'show_as_images') && $row->details->show_as_images): ?>
                                                            <img src="<?php if( !filter_var($data->{$row->field}, FILTER_VALIDATE_URL)): ?><?php echo e(Voyager::image( $data->{$row->field} )); ?><?php else: ?><?php echo e($data->{$row->field}); ?><?php endif; ?>" style="width:50px">
                                                        <?php else: ?>
                                                            <?php echo e($data->{$row->field}); ?>

                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php echo e(trans_choice('voyager::media.files', 0)); ?>

                                                    <?php endif; ?>

                                                
                                                <?php elseif($row->type == 'adv_fields_group'): ?>
                                                    <div class="browse-group-fields">
                                                        <?php
                                                            $group = json_decode($data->{$row->field});
                                                            if (!isset($group->fields) && isset($row->details->fields)) {
                                                                $fields = $row->details->fields;
                                                            } else {
                                                                $fields = $group->fields;
                                                            }
                                                        ?>
                                                        <?php if(isset($fields)): ?>
                                                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="browse-group-field" data-key="<?php echo e($key); ?>">
                                                                <?php if(!empty($field->value)): ?>
                                                                    <i class="voyager-check"></i>
                                                                <?php else: ?>
                                                                    <i class="voyager-dot"></i>
                                                                <?php endif; ?>
                                                                </span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <i class="voyager-dot"></i><i class="voyager-dot"></i><i class="voyager-dot"></i>
                                                        <?php endif; ?>
                                                        <?php if(property_exists($row->details, 'browse_inline_editor')): ?>
                                                            <button data-name="<?php echo e($row->field); ?>" class="group-inline-edit" type="button" title="<?php echo app('translator')->get('voyager-extension::bread.inline_edit'); ?>"><i class="voyager-edit"></i></button>
                                                        <?php endif; ?>
                                                    </div>

                                                
                                                <?php else: ?>
                                                    <?php echo $__env->make('voyager::multilingual.input-hidden-bread-browse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    <span><?php echo e($data->{$row->field}); ?></span>
                                                <?php endif; ?>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td class="no-sort no-click" id="bread-actions">
                                            <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(!method_exists($action, 'massAction')): ?>
                                                    <?php echo $__env->make('voyager::bread.partials.actions', ['action' => $action], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if($isServerSide): ?>
                            <div class="pull-left">
                                <div role="status" class="show-res" aria-live="polite"><?php echo e(trans_choice(
                                    'voyager::generic.showing_entries', $dataTypeContent->total(), [
                                        'from' => $dataTypeContent->firstItem(),
                                        'to' => $dataTypeContent->lastItem(),
                                        'all' => $dataTypeContent->total()
                                    ])); ?></div>
                            </div>
                            <div class="pull-right">
                                <?php echo e($dataTypeContent->appends([
                                    's' => $search->value,
                                    'filter' => $search->filter,
                                    'key' => $search->key,
                                    'order_by' => $orderBy,
                                    'sort_order' => $sortOrder,
                                    'showSoftDeleted' => $showSoftDeleted,
                                ])
                                ->onEachSide(5)
                                ->links('voyager-extension::bread.partials.pagination')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(voyager_extension_asset('js/tinytoggle/css/tinytoggle.min.css')); ?>">
<?php if(!$dataType->server_side && config('dashboard.data_tables.responsive')): ?>
    <link rel="stylesheet" href="<?php echo e(voyager_asset('lib/css/responsive.dataTables.min.css')); ?>">
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(voyager_extension_asset('js/tinytoggle/jquery.tinytoggle.min.js')); ?>"></script>
    <!-- DataTables -->
    <?php if(!$dataType->server_side && config('dashboard.data_tables.responsive')): ?>
        <script src="<?php echo e(voyager_asset('lib/js/dataTables.responsive.min.js')); ?>"></script>
    <?php endif; ?>

    <script>
        $(document).ready(function () {


            // Change Filter Selection
            $('.filter-select').on('change', function () {

                let url = $('.browse-filters-holder').data('url');
                let filter_params = '';

                let i = 0;
                $('.filter-select').each(function(index, elem) {
                    console.log($(elem).val());
                    if ($(elem).val()) {
                        filter_params = filter_params + (i > 0? '&' : '') + `field[${i}]=${$(elem).data('column')}&value[${i}]=${$(elem).val()}`;
                        i++;
                    }
                });

                if (filter_params.length === 0) {
                    window.location.replace(`${url}?reset_filters`);
                } else {
                    window.location.replace(`${url}?${filter_params}`);
                }
            });


            // Add some new functionality (hidden when we have not selected records) and change ID for using with our own handler
            $('#bulk_delete_btn').addClass('hidden').prop('id','vext_bulk_delete_btn');

            <?php if(!$dataType->server_side): ?>
                var table = $('#dataTable').DataTable(<?php echo json_encode(
                    array_merge([
                        "order" => $orderColumn,
                        "language" => __('voyager::datatable'),
                        "columnDefs" => [['targets' => -1, 'searchable' =>  false, 'orderable' => false]],
                    ],
                    config('voyager.dashboard.data_tables', []))
                , true); ?>);
            <?php else: ?>
                $('#search-input select').select2({
                    minimumResultsForSearch: Infinity
                });
            <?php endif; ?>

            <?php if($isModelTranslatable): ?>
                $('.side-body').multilingual();
                //Reinitialise the multilingual features when they change tab
                $('#dataTable').on('draw.dt', function(){
                    $('.side-body').data('multilingual').init();
                })
            <?php endif; ?>
            $('.select_all').on('click', function(e) {
                $('input[name="row_id"]').prop('checked', $(this).prop('checked')).trigger('change');
            });
        });

        <?php if($usesSoftDeletes): ?>
            <?php
                $params = [
                    's' => $search->value,
                    'filter' => $search->filter,
                    'key' => $search->key,
                    'order_by' => $orderBy,
                    'sort_order' => $sortOrder,
                ];
            ?>
            $(function() {
                $('#show_soft_deletes').change(function() {
                    if ($(this).prop('checked')) {
                        $('#dataTable').before('<a id="redir" href="<?php echo e((route('voyager.'.$dataType->slug.'.index', array_merge($params, ['showSoftDeleted' => 1]), true))); ?>"></a>');
                    }else{
                        $('#dataTable').before('<a id="redir" href="<?php echo e((route('voyager.'.$dataType->slug.'.index', array_merge($params, ['showSoftDeleted' => 0]), true))); ?>"></a>');
                    }

                    $('#redir')[0].click();
                })
            })
        <?php endif; ?>

        $('input[name="row_id"]').on('change', function () {
            var ids = [];
            $('input[name="row_id"]').each(function() {
                if ($(this).is(':checked')) {
                    ids.push($(this).val());
                }
            });

            if(ids.length > 0) {
                $('#vext_bulk_delete_btn').removeClass('hidden');
            } else {
                $('#vext_bulk_delete_btn').addClass('hidden');
            }

            $('.selected_ids').val(ids);
        });

        // Delete ONE RECORD
        $('td').on('click', '.delete', function (e) {
            vext.dialogActionRequest({
                'title': '<i class="voyager-trash"></i> <?php echo e(__("voyager::generic.delete_question")); ?>',
                'message': '<?php echo e(__("voyager::generic.delete_question")); ?> <br/>"<span class="dialog-file-name"><?php echo e(strtolower($dataType->getTranslatedAttribute('display_name_singular'))); ?>' + '</span>"',
                'class': 'vext-dialog-warning',
                'yes': '<?php echo e(__('voyager-extension::bread.dialog_button_remove')); ?>',
                'url': '<?php echo e(route('voyager.'.$dataType->slug.'.destroy', '__id')); ?>'.replace('__id', $(this).data('id')),
                'method': 'POST',
                'fields': '',
                'method_field': '<?php echo e(method_field("DELETE")); ?>',
                'csrf_field': '<?php echo e(csrf_field()); ?>'
            });
        });

        // Delete MULTI RECORDS - BULK
        $('.side-body').on('click', '#vext_bulk_delete_btn', function (e) {

            var ids = [];
            var $checkedBoxes = $('#dataTable input[name=row_id]:checked').not('.select_all');
            var count = $checkedBoxes.length;

            // Deletion info
            var displayName = count > 1 ? '<?php echo e($dataType->getTranslatedAttribute('display_name_plural')); ?>' : '<?php echo e($dataType->getTranslatedAttribute('display_name_singular')); ?>';
            displayName = displayName.toLowerCase();

            // Gather IDs
            $.each($checkedBoxes, function () {
                var value = $(this).val();
                ids.push(value);
            })

            vext.dialogActionRequest({
                'title': '<i class="voyager-trash"></i> <?php echo e(__("voyager::generic.delete_question")); ?>',
                'message': '<?php echo e(__("voyager::generic.delete_question")); ?> <br/>"<span class="dialog-file-name">' + displayName + ' (' + count + ')</span>"',
                'fields': '<input type="hidden" name="ids" id="bulk_delete_input" value="'+ ids + '">',
                'class': 'vext-dialog-warning',
                'yes': '<?php echo e(__('voyager-extension::bread.dialog_button_remove')); ?>',
                'url': '<?php echo e(route('voyager.'.$dataType->slug.'.index')); ?>/0',
                'method': 'POST',
                'method_field': '<?php echo e(method_field("DELETE")); ?>',
                'csrf_field': '<?php echo e(csrf_field()); ?>'
            });

        });

        // Clone RECORD
        $('#dataTable').on('click', '.btn.clone', function () {
            vext.dialogActionRequest({
                'message': '<?php echo e(__('voyager-extension::bread.dialog_clone_message')); ?>',
                'class': 'vext-dialog-request',
                'yes': '<?php echo e(__('voyager-extension::bread.dialog_clone_yes_button')); ?>',
                'url': '<?php echo e(route('voyager.'.$dataType->slug.'.clone', '__id')); ?>'.replace('__id', $(this).data('id')),
                'method': 'POST',
                'method_field': '',
                'fields': '',
                'csrf_field': '<?php echo e(csrf_field()); ?>'
            });
        });

        // Toggle CHECKBOXES
        $(".tiny-toggle").tinyToggle({
            onChange: function() {

                var parent = $(this).parent().parent().parent();
                var value = $(this).attr("checked") ? 1 : 0;

                params = {
                    slug: parent.data("slug"),
                    id: parent.data("record-id"),
                    field: $(this).attr("name"),
                    value: value,
                    json: null,
                    _token: '<?php echo e(csrf_token()); ?>'
                }

                updateRecord(parent, params);
            },
        });

        // Updated requested record field - helper
        function updateRecord(parent, params) {
            $.post('<?php echo e(route('voyager.'.$dataType->slug.'.ext-record-update', '__id')); ?>'.replace('__id', params.id), params, function (response) {
                if (response
                    && response.data
                    && response.data.status
                    && response.data.status == 200) {

                    toastr.success(response.data.message);

                    if (params.field === 'status') {
                        parent.toggleClass('unpublished-record');
                    }

                } else {
                    toastr.error("Error setting new value for the field.");
                }
            });
        }

        // Inline Edit button
        $('.text-inline-edit').on('click', function(e) {
            let elEditorHolder = $(this).parent().parent().find('.browse-inline-editor');
            $(this).parent().css('display','none');
            elEditorHolder.css('display','flex');
            elEditorHolder.find('input').select();
        });

        // Inline Cancel button
        $('.text-inline-cancel').on('click', function(e) {
            $(this).parent().css('display','none');
            $(this).parent().parent().find('.browse-text-holder').css('display','flex');
        });

        // Inline press Enter
        $('.browse-inline-input').keypress(function(event) {
            if (event.keyCode == 13) {
                $(this).parent().find('.text-inline-save').click();
            }
        });

        // Inline Save button
        $('.text-inline-save').on('click', function(e) {

            let elTextHolder = $(this).parent().parent().find('.browse-text-holder');
            let elInput = $(this).parent().find('input');
            let parent = $(this).parent().parent().parent().parent();

            $(this).parent().css('display','none');
            elTextHolder.css('display','flex');
            elTextHolder.find('div').html(elInput.val());

            params = {
                slug: parent.data("slug"),
                id: elInput.data("id"),
                field: elInput.attr("name"),
                value: elInput.val(),
                json: null,
                _token: '<?php echo e(csrf_token()); ?>'
            };

            updateRecord(parent, params);

        });

        // Inline Group Field Edit button
        $('.group-inline-edit').on('click', function(e) {

            let parent = $(this).parent().parent().parent();
            let elFieldsHodlder =  $(this).parent();

            params = {
                slug: parent.data("slug"),
                id: parent.data("record-id"),
                field: $(this).data("name"),
                _token: '<?php echo e(csrf_token()); ?>'
            };

            if (vext_dialog) {
                vext_dialog.close();
            }

            // Inline Group Field Dialog
            vext_dialog = new $.Zebra_Dialog('', {
                'title': "<?php echo e(__('voyager-extension::bread.dialog_inline_title')); ?>",
                'custom_class': 'dialog-field-group class',
                'type': false,
                'modal': true,
                'position': ['center', 'middle'],
                'backdrop_opacity': 0.6,
                'buttons':  [
                    {
                        caption: "<?php echo e(__('voyager-extension::bread.dialog_button_save')); ?>", callback: function() {

                            let elForm = $('.inline-group-form');
                            let elInputs = elForm.find('input');
                            let data = { fields: {}};

                            // Make a complex fields object
                            elInputs.each(function(index, elem) {
                                data.fields[$(elem).data('key')] = {
                                    type: $(elem).attr('type'),
                                    label: $(elem).data('label'),
                                    value: $(elem).val()
                                }

                                let icon = $(elem).val() && $(elem).val().length > 0? 'voyager-check' : 'voyager-dot';

                                elFieldsHodlder.find(`[data-key='${$(elem).data('key')}']`).html(`<i class="${icon}"></i>`);

                            });

                            params.value = JSON.stringify(data);

                            updateRecord(parent, params);
                        }
                    },
                    {
                        caption: vext.trans('bread.dialog_button_cancel'), callback: function() {}
                    }
                ],
                source: {
                    ajax: {
                        method: "GET",
                        url: '<?php echo e(route('voyager.'.$dataType->slug.'.ext-group.form', '__id')); ?>'.replace('__id', params.id),
                        data: params,
                        complete: function(data) {
                            vext_dialog.update();
                        }
                    }
                }
            });

        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forge/tps.laravel.touchmediahost.com/vendor/monstrex/voyager-extension/src/../resources/views/bread/browse-list.blade.php ENDPATH**/ ?>